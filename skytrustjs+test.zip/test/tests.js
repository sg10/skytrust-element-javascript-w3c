define(function() { 


    QUnit.start();

    var cp = null;

    QUnit.begin(function( details ) {
        console.log( "Test amount:", details.totalTests );
        console.log( "[test] creating IFrame" );
        var iframe = $( "<iframe src=\"#\" id=\"skytrust-iframe\" style=\"border: none;\" />" );
        $(document.body).append(iframe);
        cp = window.getCryptoProviderByName("SkyTrust");
    });
  /*
    ======== A Handy Little QUnit Reference ========
    http://api.qunitjs.com/

    Test methods:
      module(name, {[setup][ ,teardown]})
      test(name, callback)
      expect(numberOfAssertions)
      stop(increment)
      start(decrement)
    Test assertions:
      ok(value, [message])
      equal(actual, expected, [message])
      notEqual(actual, expected, [message])
      deepEqual(actual, expected, [message])
      notDeepEqual(actual, expected, [message])
      strictEqual(actual, expected, [message])
      notStrictEqual(actual, expected, [message])
      throws(block, [expected], [message])
  */

  /* require your app components
   * for example, if you have /app/modules/doSomething.js, you can
   * require(['modules/doSomething'], function(theModule) {
   *   // test the things
   * });
   */

    QUnit.test('access via window.getCryptoProviderByName()', function(assert) {
        assert.ok(window.getCryptoProviderByName !== null, "window.getCryptoProviderByName not null");
        assert.ok(cp !== null, "SkyTrust crypto provider not null")
    });

    QUnit.test('crypto functions throw error if they are called without any arguments', function(assert) {
        var functions = {};
        functions.subtle = ['encrypt', 'decrypt', 'sign', 'wrapKey', 'exportKey', 'importKey']; //...
        functions.extended = ['encryptCMS', 'decryptCMS'];

        assert.expect(functions.subtle.length + functions.extended.length);

        for(var i=0; i<functions.subtle.length; i++) {
            var fname = functions.subtle[i];
            testThrowsExceptionWithoutParameters(cp.subtle[fname], fname, assert);
        }
        for(var i=0; i<functions.extended.length; i++) {
            var fname = functions.extended[i];
            testThrowsExceptionWithoutParameters(cp.extended[fname], fname, assert);
        }
    });

    function testThrowsExceptionWithoutParameters(func, funcname, assert) {
        var MESSAGE = "calling " + funcname + " without parameters throws an error";

        var done = assert.async();
        try {
            var promise = func();
            if(promise.catch) {
                promise
                    .then(function(result) {
                        console.log("[test]" + result);
                        assert.ok(false, MESSAGE + ": promise resolved (success)");
                    })
                    .catch(function(error) { 
                        assert.ok(true, MESSAGE + ": promise rejected (" + error + ")");
                        done();
                    });
            }
        }catch(error) {
            assert.ok(true, MESSAGE + ": exception before returning a promise (" + error + ")");
            done();
        }
    }

    QUnit.test('digest, verify, deriveKey, deriveBits throw OperationNotSupported error', function(assert) {
        var functions = ['digest', 'verify', 'deriveKey', 'deriveBits'];

        assert.expect(functions.length);

        for(var i=0; i<functions.length; i++) {
            var fname = functions[i];
            testNotSupported(cp.subtle[fname], fname, assert);
        }
    });

    function testNotSupported(func, funcname, assert) {
        var MESSAGE = funcname + "() throws not supported error";

        var done = assert.async();
        try {
            var promise = func();
        }catch(e) {
            assert.equal(e.name, "OperationNotSupported", MESSAGE);
            done();
        }
    }

    QUnit.test('test CMS encrypt and decrypt large file', function(assert) {
        assert.expect(6);

        var str0 = "hello";
        var str1 = "world";

        var data0 = str2ab(str0);
        var data1 = str2ab(str1);

        var done1 = assert.async();
        cp.extended.listKeys()
          .then(function(keys) {
            
            var key0 = keys[0];
            var key1 = keys[1];

            assert.ok(typeof key0 !== "undefined", "loaded first CryptoKey from server");
            assert.ok(typeof key1 !== "undefined", "loaded second CryptoKey from server");
            done1();

            var done2 = assert.async();
            cp.extended.encryptCMS('CMS-AES-192-CCM', [key0, key1], [data0, data1])
              .then(function(dataEncrypted) {

                assert.ok(dataEncrypted.length === 2, "expecting two encrypted byte arrays");
                done2();

                var done3 = assert.async();
                cp.extended.decryptCMS('CMS-AES-192-CCM', key1, [dataEncrypted[0], dataEncrypted[1]])
                  .then(function(dataDecrypted) {

                        assert.ok(dataDecrypted.length === 2, "expecting two decrypted byte arrays");
                        assert.equal(str0, ab2str(dataDecrypted[0]), "expecting decrypted string 0 to equal input string 0");
                        assert.equal(str1, ab2str(dataDecrypted[1]), "expecting decrypted string 1 to equal input string 1");
                        done3();

                  });

            });

        });

    });

    function ab2str(buf) {
        var ui16 = new Uint16Array(buf);
        return String.fromCharCode.apply(null, ui16);
    }

    function str2ab(str, l) {
        var length = (l == null) ? str.length*2 : l;
        var buf = new ArrayBuffer(length); // 2 bytes for each char
        var bufView = new Uint16Array(buf);
        for (var i=0, strLen=str.length; i<strLen; i++) {
            bufView[i] = str.charCodeAt(i);
        }
        return buf;
    }

});
